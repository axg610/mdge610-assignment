var searchData=
[
  ['add',['add',['../classUnitigColors.html#aefd6309649156f4a1035f8381270d225',1,'UnitigColors::add()'],['../classCompactedDBG.html#a3c884106eb285d837918ddf53ca422bf',1,'CompactedDBG::add()']]]
];
