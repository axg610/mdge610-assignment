var searchData=
[
  ['_7ecompacteddbg',['~CompactedDBG',['../classCompactedDBG.html#a64299c748d198a2596facfd39c2bd280',1,'CompactedDBG']]],
  ['_7eunitigcolors',['~UnitigColors',['../classUnitigColors.html#af0b4c187dcb539a57bc39c924af8de54',1,'UnitigColors']]]
];
