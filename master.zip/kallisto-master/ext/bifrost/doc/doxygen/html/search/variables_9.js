var searchData=
[
  ['outfilenamebbf',['outFilenameBBF',['../structCDBG__Build__opt.html#aa10751be5fcf01b1686cce66ebab733e',1,'CDBG_Build_opt']]],
  ['outputcolors',['outputColors',['../structCCDBG__Build__opt.html#a8139bdba04c0dbb93c653c9a451b05f6',1,'CCDBG_Build_opt']]],
  ['outputgfa',['outputGFA',['../structCDBG__Build__opt.html#a59256092145b2e12068a0874e3bffa94',1,'CDBG_Build_opt']]]
];
