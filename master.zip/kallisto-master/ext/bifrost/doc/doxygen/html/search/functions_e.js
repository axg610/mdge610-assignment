var searchData=
[
  ['read',['read',['../classColoredCDBG.html#a513ae8190f56a26b088a99e1e33689d8',1,'ColoredCDBG::read()'],['../classUnitigColors.html#a6bc79eb9e7c5b94dfbf8235033d32af5',1,'UnitigColors::read()'],['../classCompactedDBG.html#a0930cb63a158caa70f4dcd425a088fb4',1,'CompactedDBG::read()'],['../classKmer.html#ad7e63cd4337067ac247a52f4b8235204',1,'Kmer::read()']]],
  ['referenceunitigtostring',['referenceUnitigToString',['../classUnitigMap.html#a90ab8fbec322df04053b9998c68d2070',1,'UnitigMap']]],
  ['remove',['remove',['../classUnitigColors.html#a31e28cb0fdb60ba373af28bab79cce40',1,'UnitigColors::remove()'],['../classCompactedDBG.html#aa8e901dc6f1cf0adcc91608a6b34e999',1,'CompactedDBG::remove()']]],
  ['rep',['rep',['../classKmer.html#a2b86fe792388a910a073d9fc4a811779',1,'Kmer']]]
];
