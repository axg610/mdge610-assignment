var searchData=
[
  ['searchsequence',['searchSequence',['../classCompactedDBG.html#af27c7bcb26d05371bdcc12075b4724eb',1,'CompactedDBG']]],
  ['selfforwardbase',['selfForwardBase',['../classKmer.html#a605ec250880652507ae279f348046936',1,'Kmer']]],
  ['serialize',['serialize',['../classCCDBG__Data__t.html#ab29386cdf5ae12239c0a87d510f7aa40',1,'CCDBG_Data_t::serialize()'],['../classCDBG__Data__t.html#a4c6ec7ef1a4ca46bd643f59d25730945',1,'CDBG_Data_t::serialize()'],['../classDataAccessor.html#aae08bdd0b2c5d077672be826f112cfe1',1,'DataAccessor::serialize()']]],
  ['set_5fdeleted',['set_deleted',['../classKmer.html#aed7e4989323e49f78e3b0ceeaedc21b4',1,'Kmer']]],
  ['set_5fempty',['set_empty',['../classKmer.html#a13f76eacb925e986280191035788bc03',1,'Kmer']]],
  ['set_5fk',['set_k',['../classKmer.html#ae76504dbc6fe791fadc50667852a62c8',1,'Kmer']]],
  ['setchar',['setChar',['../classKmer.html#acd1e99defb65ea71c7cf804d3f1e3dc4',1,'Kmer']]],
  ['simplify',['simplify',['../classCompactedDBG.html#aa8c574863bed96d2a9415cbe3d154de6',1,'CompactedDBG']]],
  ['size',['size',['../classUnitigColors.html#ad410a06bb105a496951c805c69d65f5f',1,'UnitigColors::size(const UnitigMapBase &amp;um) const'],['../classUnitigColors.html#a354c6f26708ddbd2223f1f58d695dc32',1,'UnitigColors::size(const UnitigMapBase &amp;um, const size_t color_id) const'],['../classCompactedDBG.html#ad0c9c06a0d88cd230eabf889900ecd17',1,'CompactedDBG::size()']]]
];
