var searchData=
[
  ['filename_5fcolors_5fin',['filename_colors_in',['../structCCDBG__Build__opt.html#a5a0ffdd2103dcc0087f99731dcbcdc9f',1,'CCDBG_Build_opt']]],
  ['filename_5fgraph_5fin',['filename_graph_in',['../structCDBG__Build__opt.html#a121574067fffe9fa3c0c280ec633ffc3',1,'CDBG_Build_opt']]],
  ['filename_5fref_5fin',['filename_ref_in',['../structCDBG__Build__opt.html#a4d0d3e899b64c6bbc9e5913375ba40e3',1,'CDBG_Build_opt']]],
  ['filename_5fseq_5fin',['filename_seq_in',['../structCDBG__Build__opt.html#abb43cea644ca04c5ed0c3034b03c70d4',1,'CDBG_Build_opt']]]
];
