var searchData=
[
  ['infilenamebbf',['inFilenameBBF',['../structCDBG__Build__opt.html#aede0acb7ddd4b5bf7c6c539a86461d15',1,'CDBG_Build_opt']]],
  ['isempty',['isEmpty',['../structUnitigMapBase.html#ade629940b2611494dbf233cb1144da80',1,'UnitigMapBase']]]
];
