var searchData=
[
  ['nb_5fbits_5fnon_5funique_5fkmers_5fbf',['nb_bits_non_unique_kmers_bf',['../structCDBG__Build__opt.html#a0923610123fa39ddabff3863149b9636',1,'CDBG_Build_opt']]],
  ['nb_5fbits_5funique_5fkmers_5fbf',['nb_bits_unique_kmers_bf',['../structCDBG__Build__opt.html#a863fc8d612ec6fa3ba54ac970a83065c',1,'CDBG_Build_opt']]],
  ['nb_5fthreads',['nb_threads',['../structCDBG__Build__opt.html#a788622fc88a1957d46d84feab8086d0c',1,'CDBG_Build_opt']]]
];
