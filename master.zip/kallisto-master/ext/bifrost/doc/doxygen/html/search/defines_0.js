var searchData=
[
  ['v_5fnot_5fvisited',['V_NOT_VISITED',['../snippets_8h.html#abeb188df21ec971c69153463711c533b',1,'snippets.h']]],
  ['v_5fvisited',['V_VISITED',['../snippets_8h.html#aaaef815ed6556662f874b106601e7343',1,'snippets.h']]]
];
