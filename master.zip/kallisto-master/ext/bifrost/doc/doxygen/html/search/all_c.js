var searchData=
[
  ['nb_5fbits_5fnon_5funique_5fkmers_5fbf',['nb_bits_non_unique_kmers_bf',['../structCDBG__Build__opt.html#a0923610123fa39ddabff3863149b9636',1,'CDBG_Build_opt']]],
  ['nb_5fbits_5funique_5fkmers_5fbf',['nb_bits_unique_kmers_bf',['../structCDBG__Build__opt.html#a863fc8d612ec6fa3ba54ac970a83065c',1,'CDBG_Build_opt']]],
  ['nb_5fthreads',['nb_threads',['../structCDBG__Build__opt.html#a788622fc88a1957d46d84feab8086d0c',1,'CDBG_Build_opt']]],
  ['neighboriterator',['neighborIterator',['../classneighborIterator.html',1,'neighborIterator&lt; Unitig_data_t, Graph_data_t, is_const &gt;'],['../classneighborIterator.html#ab857cd8f2e6bb98f844d9316c8e8d5b5',1,'neighborIterator::neighborIterator()'],['../classneighborIterator.html#a3a524d5ee6219ea7ccc3a11f69d80835',1,'neighborIterator::neighborIterator(const UnitigMap&lt; U, G, is_const &gt; &amp;um_, const bool is_forward_)'],['../classneighborIterator.html#ad7ee6efe87e4c4619c96e6c4fae809df',1,'neighborIterator::neighborIterator(const neighborIterator &amp;o)']]],
  ['neighboriterator_2ehpp',['NeighborIterator.hpp',['../NeighborIterator_8hpp.html',1,'']]],
  ['nextcolor',['nextColor',['../classUnitigColors_1_1UnitigColors__const__iterator.html#ae7c489b968f06a0b713bd7244d75aeca',1,'UnitigColors::UnitigColors_const_iterator']]]
];
